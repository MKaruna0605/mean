const express = require('express');
const routes = express.Router();
const Profile = require('../Models/Profiles');

routes.post('/createProfile', (req, res) => {
    Profile.findOne({ name: req.body.name }, (err, data) => {
        if (err) throw err;
        if (data) {
            res.json({ success: false, msg: "Data already exists" })
        } else {
            Profile.create(req.body, (err, result) => {
                if (err) throw err;
                res.json({ success: true, data: result, msg: "Data Inserted successfully" })
            })
        }
    })

});
routes.get('/getUser/:id', (req, res) => {
    Profile.findOne({ _id: req.params.id }, (err, result) => {
        if (err) throw err;
        res.json({ success: true, data: result })
    })
})
routes.get('/getAllProfiles', (req, res) => {
    Profile.find((err, result) => {
        if (err) throw err;
        res.json({ success: true, data: result })
    })
})

routes.put('/updateProfile', (req, res) => {
    updateFields = {
        name: req.body.name,
        mobile: req.body.mobile,
        email: req.body.email,
        password: req.body.password,
    }
    console.log(req.body);
    Profile.findOneAndUpdate({ _id: req.body.id }, updateFields, (err, result) => {
        if (err) throw err;
        res.json({ success: true, data: result, msg: "profile updated successfully" })
    })
})

routes.delete('/deleteUser/:id', (req, res) => {
    Profile.deleteOne({ _id: req.params.id }, (err, result) => {
        if (err) throw err;
        res.json({ success: true, msg: "User deleted successfully" });
    })
})
module.exports = routes;