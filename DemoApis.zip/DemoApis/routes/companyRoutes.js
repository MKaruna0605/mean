const express = require('express');
const routes = express.Router();
const Company = require('../Models/company');

routes.post('/insertCompanyDetails', (req, res) => {
    Company.create(req.body, (err, result) => {
        if (err) throw err;
        else {
            res.json({ success: true, data: result });
        }
    })
})


module.exports = routes;