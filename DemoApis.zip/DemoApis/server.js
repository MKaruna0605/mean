const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const profilRoutes = require('./routes/profileRoutes');
const companyRoutes = require('./routes/companyRoutes');
const app = express();
const db = require('./config/db');

const port = process.env.PORT || 9001;

mongoose.connect(db.url, { useNewUrlParser: true, useUnifiedTopology: true }, (err) => {
    if (err) throw err;
    else {
        console.log("Database Created");
    }
})
app.use(bodyParser.json());
app.use(cors())
app.use('/apis', profilRoutes, companyRoutes);

app.listen(port, () => {
    console.log("Server running on port:" + port);
})