const mongoose = require('mongoose');
var schema = mongoose.Schema({
    companyName: String,
    companyEmail: String,
    companyMobile: Number,
    location: String,
    pincode: Number
});
var company = mongoose.model('companydetail', schema);

module.exports = company;