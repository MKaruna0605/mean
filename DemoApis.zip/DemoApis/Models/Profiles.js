const mongoose = require('mongoose');
var schema = mongoose.Schema({
    name: String,
    email: String,
    mobile: Number,
    password: String
});
var profile = mongoose.model('profile', schema);

module.exports = profile;